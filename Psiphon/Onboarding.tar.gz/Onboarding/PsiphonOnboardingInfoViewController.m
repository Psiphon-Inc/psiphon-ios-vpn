/*
 * Copyright (c) 2017, Psiphon Inc.
 * All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#import "PsiphonOnboardingInfoViewController.h"
#import "PsiCashBalanceWithSpeedBoostMeter.h"

#define k5sScreenWidth 320.f

// 2nd to Nth onboarding screen(s) after the language
// selection screen (OnboardingLanguageViewController).
// These views display onboarding text describing
// Psiphon Browser to the user.
// Note: we should have the full screen to work with
// because OnboardingViewController should not be presenting
// any other views.
@implementation PsiphonOnboardingInfoViewController {
	UIView *contentView;
	UIView *graphic;
	UILabel *titleView;
	UILabel *textView;
}

@synthesize index = _index;
@synthesize delegate = delegate;

- (void)viewDidLoad {
	[super viewDidLoad];

    [self addTitleView];
    [self addTextView];
    [self setPageSpecificContent];
    [self addContentView];
    [self setupLayoutConstraints];
}

- (void)setPageSpecificContent {
    /* Set page specific content */
    switch (self.index) {
        case PsiphonOnboardingPage1Index: {
            [self setGraphicAsCoin];
            titleView.text = @"Say hello to PsiCash"; //NSLocalizedStringWithDefaultValue(@"ONBOARDING_ACCESS_TITLE", nil, [NSBundle mainBundle], @"Access the Web", @"Title text on one of the on-boarding screens");
            textView.text = @"A new way for you to enjoy maximum speeds, absolutely free."; //NSLocalizedStringWithDefaultValue(@"ONBOARDING_ACCESS_TEXT", nil, [NSBundle mainBundle], @"The Internet at your fingertips", @"Body text on one of the on-boarding screens. It is indicating to the user that Psiphon Browser allows them to access the Internet (without censorship).");
            break;
        }
        case PsiphonOnboardingPage2Index: {
            [self setGraphicAsSpeedBoostMeter];
            titleView.text = @"Your PsiCash balance"; //NSLocalizedStringWithDefaultValue(@"ONBOARDING_APPS_TITLE", nil, [NSBundle mainBundle], @"Your Apps in Your Browser", @"Title text on one of the on-boarding screens. The intention of this screen is to let the user know that their sites and services -- Facebook, Twitter, etc. -- can be accessed within Psiphon Browser via web pages.");
            textView.text =  @"Earn PsiCash whenever you connect with Psiphon."; //NSLocalizedStringWithDefaultValue(@"ONBOARDING_APPS_TEXT", nil, [NSBundle mainBundle], @"Your favorite apps have a web interface that works great in Psiphon Browser", @"Body text on one of the on-boarding screens. The intention of this screen is to let the user know that their sites and services -- Facebook, Twitter, etc. -- can be accessed within Psiphon Browser via web pages. DO NOT translate 'Psiphon'.");
            break;
        }
        case PsiphonOnboardingPage3Index: {
            [self setGraphicAsSpeedBoostMeter];
            titleView.text = @"Speed Boost"; //NSLocalizedStringWithDefaultValue(@"ONBOARDING_BROWSING_TITLE", nil, [NSBundle mainBundle], @"Happy Browsing!", @"Title text on one of the on-boarding screens. This is the final page of the on-boarding and is sending the user off on their journey across the Internet.");
            textView.text = @"When you've collected enough PsiCash, you can activate Speed Boost and enjoy Psiphon at max speed!";
            break;
        }
        default:
            [self onboardingEnded];
            break;
    }
}

- (void)setGraphicAsCoin {
    /* setup graphic view */
    UIImageView *imageView = [[UIImageView alloc] init];
    UIImage *graphicImage = [UIImage imageNamed:@"PsiCash_Coin"];
    if (graphicImage != nil) {
        imageView.image = graphicImage;
    }
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    [imageView.layer setMinificationFilter:kCAFilterTrilinear]; // Prevent aliasing

    graphic = imageView;
    [self.view addSubview:graphic];

    // Setup layout constraints
    CGFloat coinSize = 120.f;
    [graphic.bottomAnchor constraintEqualToAnchor:self.view.centerYAnchor constant:coinSize/4].active = YES;
    [graphic.widthAnchor constraintEqualToConstant:coinSize].active = YES;
    [graphic.heightAnchor constraintEqualToConstant:coinSize].active = YES;
    [graphic.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor].active = YES;
}

- (void)setGraphicAsSpeedBoostMeter {
    PsiCashSpeedBoostProductSKU *sku = [PsiCashSpeedBoostProductSKU skuWitDistinguisher:@"1h" withHours:[NSNumber numberWithInteger:1] andPrice:[NSNumber numberWithInteger:1e9]];
    PsiCashBalanceWithSpeedBoostMeter *meter = [[PsiCashBalanceWithSpeedBoostMeter alloc] init];

    UInt64 balance = 0;
    if (self.index == PsiphonOnboardingPage2Index) {
        balance = 0.41e9;
    } else if (self.index == PsiphonOnboardingPage3Index) {
        balance = 1e9;
    }

    PsiCashClientModel *m = [PsiCashClientModel clientModelWithAuthPackage:[[PsiCashAuthPackage alloc] initWithValidTokens:@[@"indicator", @"earner", @"spender"]]
                                                       andBalanceInNanoPsi:balance
                                                      andSpeedBoostProduct:[PsiCashSpeedBoostProduct productWithSKUs:@[sku]]
                                                       andPendingPurchases:nil
                                               andActiveSpeedBoostPurchase:nil];
    [meter bindWithModel:m];
    graphic = meter;
    [self.view addSubview:graphic];

    // Setup layout constraints
    [graphic.bottomAnchor constraintEqualToAnchor:self.view.centerYAnchor constant:0].active = YES;
    [graphic.widthAnchor constraintEqualToAnchor:self.view.widthAnchor multiplier:1].active = YES;
    [graphic.heightAnchor constraintEqualToConstant:100].active = YES;
    [graphic.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor].active = YES;
}

- (void)addTitleView {
    /* Setup title view */
    titleView = [[UILabel alloc] init];
    titleView.numberOfLines = 0;
    titleView.adjustsFontSizeToFitWidth = YES;
    titleView.userInteractionEnabled = NO;
    titleView.font = [UIFont boldSystemFontOfSize:(self.view.frame.size.width - k5sScreenWidth) * 0.0134f + 19.0f];
    titleView.textColor = [UIColor whiteColor];
    titleView.textAlignment = NSTextAlignmentCenter;

}

- (void)addTextView {
    /* Setup text view */
    textView = [[UILabel alloc] init];
    textView.numberOfLines = 0;
    textView.adjustsFontSizeToFitWidth = YES;
    textView.userInteractionEnabled = NO;
    textView.font = [UIFont systemFontOfSize:(self.view.frame.size.width - k5sScreenWidth) * 0.0112f + 18.0f];
    textView.textColor = [UIColor whiteColor];
    textView.textAlignment = NSTextAlignmentCenter;
}

- (void)addContentView {
    contentView = [[UIView alloc] init];
    [contentView addSubview:titleView];
    [contentView addSubview:textView];
    [self.view addSubview:contentView];
}

- (void)setupLayoutConstraints {
    /* Setup autolayout */
    graphic.translatesAutoresizingMaskIntoConstraints = NO;
    contentView.translatesAutoresizingMaskIntoConstraints = NO;
    titleView.translatesAutoresizingMaskIntoConstraints = NO;
    textView.translatesAutoresizingMaskIntoConstraints = NO;

    NSDictionary *viewsDictionary = @{
                                      @"graphic": graphic,
                                      @"contentView": contentView,
                                      @"titleView": titleView,
                                      @"textView": textView
                                      };

    /* contentView's constraints */
    CGFloat contentViewWidthRatio = 0.8f;

    [contentView.widthAnchor constraintEqualToAnchor:self.view.widthAnchor multiplier:contentViewWidthRatio].active = YES;
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[graphic]-(>=20)-[contentView]|" options:0 metrics:nil views:viewsDictionary]];
    [contentView.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor].active = YES;

    /* titleView's constraints */
    [titleView.widthAnchor constraintEqualToAnchor:contentView.widthAnchor].active = YES;

    titleView.preferredMaxLayoutWidth = contentViewWidthRatio * self.view.frame.size.width;
    [titleView setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];
    [titleView setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];

    [titleView.heightAnchor constraintLessThanOrEqualToAnchor:contentView.heightAnchor multiplier:.3f].active = YES;
    [titleView.centerXAnchor constraintEqualToAnchor:contentView.centerXAnchor].active = YES;

    [NSLayoutConstraint constraintWithItem:titleView
                                 attribute:NSLayoutAttributeCenterY
                                 relatedBy:NSLayoutRelationEqual
                                    toItem:contentView
                                 attribute:NSLayoutAttributeCenterY
                                multiplier:.5f constant:0.f].active = YES;

    /* textView's constraints */
    [textView.widthAnchor constraintEqualToAnchor:contentView.widthAnchor].active = YES;

    textView.preferredMaxLayoutWidth = 0.9 * contentViewWidthRatio * self.view.frame.size.width;
    [textView setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];
    [textView setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];

    [textView.centerXAnchor constraintEqualToAnchor:contentView.centerXAnchor].active = YES;

    /* add vertical constraints for contentView's subviews */
    [contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[titleView]-[textView]-(>=0)-|" options:0 metrics:nil views:viewsDictionary]];
}

- (void)onboardingEnded {
	id<PsiphonOnboardingChildViewControllerDelegate> strongDelegate = self.delegate;

	if ([strongDelegate respondsToSelector:@selector(onboardingEnded)]) {
		[strongDelegate onboardingEnded];
	}
}

@end
