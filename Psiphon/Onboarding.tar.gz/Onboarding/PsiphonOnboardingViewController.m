/*
 * Copyright (c) 2017, Psiphon Inc.
 * All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#import "AppDelegate.h"
#import "PsiphonOnboardingViewController.h"
#import "PsiphonOnboardingInfoViewController.h"
#import "PsiphonClientCommonLibraryHelpers.h"

#define kNumOnboardingViews 3
#define kSubtitleFontName @"SanFranciscoDisplay-Regular"

@implementation PsiphonOnboardingViewController {
    // UI elements
    UILabel *appTitleLabel;
    UILabel *appSubTitleLabel;
	UIButton *nextButton;

	CGFloat bannerOffset;

	NSLayoutConstraint *titleViewTopConstraint;

    // UI Layer
    CAGradientLayer *backgroundGradient1;
    CAGradientLayer *backgroundGradient2;

	BOOL isRTL;
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    backgroundGradient1.frame = self.view.bounds;
    backgroundGradient2.frame = self.view.bounds;
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}

- (void)viewDidLoad {
	[super viewDidLoad];

	isRTL = ([UIApplication sharedApplication].userInterfaceLayoutDirection == UIUserInterfaceLayoutDirectionRightToLeft);

    [self setBackgroundGradient];
	[self.view setBackgroundColor:[UIColor clearColor]];

    [self addAppTitleLabel];
    [self addAppSubTitleLabel];

	/* Customize UIPageControl */
	UIPageControl *pageControl = [UIPageControl appearance];
	pageControl.pageIndicatorTintColor = [UIColor colorWithRed:0.00 green:0.00 blue:0.00 alpha:.34f];
    pageControl.currentPageIndicatorTintColor = [UIColor whiteColor];
	pageControl.backgroundColor = [UIColor clearColor];
	pageControl.opaque = NO;

	/* Setup UIPageViewController */
	self.pageController = [[UIPageViewController alloc] initWithTransitionStyle:UIPageViewControllerTransitionStyleScroll navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal options:nil];
	self.pageController.dataSource = self;
	self.pageController.delegate = self;
	self.pageController.view.frame = self.view.bounds;

	/* Setup and present initial PsiphonOnboardingChildViewController */
	UIViewController<PsiphonOnboardingChildViewController> *initialViewController = [self viewControllerAtIndex:0];
	NSArray *viewControllers = [NSArray arrayWithObject:initialViewController];

	[self.pageController setViewControllers:viewControllers direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
	[self addChildViewController:self.pageController];

	[self.view addSubview:self.pageController.view];
	[self.pageController didMoveToParentViewController:self];

	/* Add static views to OnboardingViewController */

	/* Setup skip button */
	nextButton = [[UIButton alloc] init];
	[nextButton setTitle:@"NEXT"/*NSLocalizedStringWithDefaultValue(@"ONBOARDING_SKIP_BUTTON", nil, [NSBundle mainBundle], @"SKIP", @"Text of button at the top right or left (depending on rtl) of the onboarding screens which allows user to skip onboarding")*/ forState:UIControlStateNormal];
	[nextButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[nextButton.titleLabel setFont:[UIFont systemFontOfSize:16]];
	[nextButton.titleLabel setAdjustsFontSizeToFitWidth:YES];

	[nextButton addTarget:self
				   action:@selector(moveToNextPage)
		 forControlEvents:UIControlEventTouchUpInside];

	[self.view addSubview:nextButton];

	nextButton.translatesAutoresizingMaskIntoConstraints = NO;

    id <UILayoutSupport> bottomLayoutGuide =  self.bottomLayoutGuide;

	NSDictionary *viewsDictionary = @{
									  @"bottomLayoutGuide": bottomLayoutGuide,
									  @"nextButton": nextButton,
									  };

	[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[nextButton]-[bottomLayoutGuide]" options:0 metrics:nil views:viewsDictionary]];
	[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[nextButton]-|" options:0 metrics:nil views:viewsDictionary]];
    // TODO: next button height
    //[nextButton.heightAnchor constraintEqualToAnchor:self.view.heightAnchor multiplier:.4f].active = YES;

	UITapGestureRecognizer *tutorialPress =
	[[UITapGestureRecognizer alloc] initWithTarget:self
											action:@selector(moveToNextPage)];
	[self.view addGestureRecognizer:tutorialPress];
}


- (void)addAppTitleLabel {
    appTitleLabel = [[UILabel alloc] init];
    appTitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    appTitleLabel.text = @"PSIPHON";
    appTitleLabel.textAlignment = NSTextAlignmentCenter;
    appTitleLabel.textColor = [UIColor whiteColor];
    CGFloat narrowestWidth = self.view.frame.size.width;
    if (self.view.frame.size.height < self.view.frame.size.width) {
        narrowestWidth = self.view.frame.size.height;
    }
    appTitleLabel.font = [UIFont fontWithName:@"Bourbon-Oblique" size:narrowestWidth * 0.10625f];
    if ([PsiphonClientCommonLibraryHelpers unsupportedCharactersForFont:appTitleLabel.font.fontName withString:appTitleLabel.text]) {
        appTitleLabel.font = [UIFont systemFontOfSize:narrowestWidth * 0.075f];
    }

    [self.view addSubview:appTitleLabel];

    // Setup autolayout
    CGFloat labelHeight = [self getLabelHeight:appTitleLabel];
    [appTitleLabel.heightAnchor constraintEqualToConstant:labelHeight].active = YES;

    NSLayoutConstraint *floatingVerticallyConstraint =[NSLayoutConstraint constraintWithItem:appTitleLabel
                                                                                   attribute:NSLayoutAttributeBottom
                                                                                   relatedBy:NSLayoutRelationEqual
                                                                                      toItem:self.view
                                                                                   attribute:NSLayoutAttributeBottom
                                                                                  multiplier:.14
                                                                                    constant:0];
    // This constraint will be broken in case the next constraint can't be enforced
    floatingVerticallyConstraint.priority = 999;
    [self.view addConstraint:floatingVerticallyConstraint];

    [appTitleLabel.topAnchor constraintGreaterThanOrEqualToAnchor:self.view.topAnchor].active = YES;
    [appTitleLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor].active = YES;
}

- (void)addAppSubTitleLabel {
    appSubTitleLabel = [[UILabel alloc] init];
    appSubTitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    appSubTitleLabel.text = NSLocalizedStringWithDefaultValue(@"APP_SUB_TITLE_MAIN_VIEW", nil, [NSBundle mainBundle], @"BEYOND BORDERS", @"Text for app subtitle on main view.");
    appSubTitleLabel.textAlignment = NSTextAlignmentCenter;
    appSubTitleLabel.textColor = [UIColor whiteColor];
    CGFloat narrowestWidth = self.view.frame.size.width;
    if (self.view.frame.size.height < self.view.frame.size.width) {
        narrowestWidth = self.view.frame.size.height;
    }
    appSubTitleLabel.font = [UIFont fontWithName:@"Bourbon-Oblique" size:narrowestWidth * 0.10625f/2.0f];
    if ([PsiphonClientCommonLibraryHelpers unsupportedCharactersForFont:appSubTitleLabel.font.fontName withString:appSubTitleLabel.text]) {
        appSubTitleLabel.font = [UIFont systemFontOfSize:narrowestWidth * 0.075f/2.0f];
    }

    [self.view addSubview:appSubTitleLabel];

    // Setup autolayout
    CGFloat labelHeight = [self getLabelHeight:appSubTitleLabel];
    [appSubTitleLabel.heightAnchor constraintEqualToConstant:labelHeight].active = YES;
    [appSubTitleLabel.topAnchor constraintEqualToAnchor:appTitleLabel.bottomAnchor].active = YES;
    [appSubTitleLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor].active = YES;
}

// TODO: this is here and in main view controller
// From https://stackoverflow.com/questions/27374612/how-do-i-calculate-the-uilabel-height-dynamically
- (CGFloat)getLabelHeight:(UILabel*)label {
    CGSize constraint = CGSizeMake(label.frame.size.width, CGFLOAT_MAX);
    CGSize size;

    NSStringDrawingContext *context = [[NSStringDrawingContext alloc] init];
    CGSize boundingBox = [label.text boundingRectWithSize:constraint
                                                  options:NSStringDrawingUsesLineFragmentOrigin
                                               attributes:@{NSFontAttributeName:label.font}
                                                  context:context].size;

    size = CGSizeMake(ceil(boundingBox.width), ceil(boundingBox.height));

    return size.height;
}

- (void)setBackgroundGradient {
    backgroundGradient1 = [CAGradientLayer layer];
    backgroundGradient1.colors = @[(id)[UIColor colorWithRed:0.63 green:0.87 blue:0.99 alpha:1.0].CGColor, (id)[UIColor colorWithRed:0.88 green:0.92 blue:1.00 alpha:1.0].CGColor];

    backgroundGradient2 = [CAGradientLayer layer];
    backgroundGradient2.colors = @[(id)[UIColor colorWithRed:0.33 green:0.47 blue:1.00 alpha:0].CGColor, (id)[UIColor colorWithRed:0.01 green:0.23 blue:1.00 alpha:.5].CGColor];

    [self.view.layer insertSublayer:backgroundGradient1 atIndex:0];
    [self.view.layer insertSublayer:backgroundGradient2 atIndex:1];


}

- (void)setNavButtonTitle {
    UIViewController <PsiphonOnboardingChildViewController>*presentedViewController = [_pageController.viewControllers objectAtIndex:0];
    if (presentedViewController.index == PsiphonOnboardingPage3Index) {
        [nextButton setTitle:@"DONE" forState:UIControlStateNormal];
    } else {
        [nextButton setTitle:@"NEXT" forState:UIControlStateNormal];
    }
}


#pragma mark - UIPageViewControllerDelegate methods and helper functions

- (void)pageViewController:(UIPageViewController *)pageViewController didFinishAnimating:(BOOL)finished previousViewControllers:(NSArray<UIViewController *> *)previousViewControllers transitionCompleted:(BOOL)completed {
    [self setNavButtonTitle];
}

- (void)pageViewController:(UIPageViewController *)pageViewController willTransitionToViewControllers:(NSArray<UIViewController *> *)pendingViewControllers {
	UIViewController <PsiphonOnboardingChildViewController>*presentedViewController = [_pageController.viewControllers objectAtIndex:0];
	UIViewController <PsiphonOnboardingChildViewController>*pendingViewController = (UIViewController <PsiphonOnboardingChildViewController> *)[pendingViewControllers objectAtIndex:0];
}


- (NSInteger)getCurrentPageIndex {
	if ([_pageController.viewControllers count] == 0) {
		return 0;
	}

	UIViewController <PsiphonOnboardingChildViewController>*presentedViewController = [_pageController.viewControllers objectAtIndex:0];
	return presentedViewController.index;
}

#pragma mark - UIPageViewControllerDataSource methods and helper functions

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController {

	NSUInteger index = [(UIViewController <PsiphonOnboardingChildViewController>*)viewController index];

	if (index == 0) {
		return nil;
	}

	index--;

	return [self viewControllerAtIndex:index];
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController {

	NSUInteger index = [(UIViewController <PsiphonOnboardingChildViewController>*)viewController index];

	index++;

	if (index == kNumOnboardingViews) {
		return nil;
	}

	return [self viewControllerAtIndex:index];
}

- (UIViewController <PsiphonOnboardingChildViewController>*)viewControllerAtIndex:(NSUInteger)index {
	UIViewController<PsiphonOnboardingChildViewController> *childViewController;
    childViewController = [[PsiphonOnboardingInfoViewController alloc] init];
	childViewController.delegate = self;
	childViewController.index = index;

	return childViewController;
}

- (NSInteger)presentationCountForPageViewController:(UIPageViewController *)pageViewController {
	// The number of items in the UIPageControl
    return kNumOnboardingViews;
}

- (NSInteger)presentationIndexForPageViewController:(UIPageViewController *)pageViewController {
	// The selected dot in the UIPageControl
	return [self getCurrentPageIndex];
}

#pragma mark - PsiphonOnboardingChildViewController delegate methods

- (CGFloat)getBannerOffset {
    return appSubTitleLabel.frame.origin.y + appSubTitleLabel.frame.size.height;
}

- (CGFloat)getTitleOffset {
    return appSubTitleLabel.frame.origin.y + appSubTitleLabel.frame.size.height;
}

- (void)moveToNextPage {
	[self moveToViewAtIndex:[self getCurrentPageIndex]+1];
}

- (void)moveToViewAtIndex:(NSInteger)index {
	if (index >= kNumOnboardingViews) {
		[self onboardingEnded];
	} else {
        __weak PsiphonOnboardingViewController *weakSelf = self;
        [self.pageController setViewControllers:@[[self viewControllerAtIndex:index]] direction:isRTL ? UIPageViewControllerNavigationDirectionReverse : UIPageViewControllerNavigationDirectionForward animated:YES completion:^(BOOL finished) {
            [weakSelf setNavButtonTitle];
        }];
	}
}

- (void)onboardingEnded {
	id<PsiphonOnboardingViewControllerDelegate> strongDelegate = self.delegate;

	if ([strongDelegate respondsToSelector:@selector(onboardingEnded)]) {
		[strongDelegate onboardingEnded];
	}
    [self dismissViewControllerAnimated:YES completion:^{

    }];
}

@end
